<?php
include 'header.php';
?>
<br>
<hr width="40%"style="opacity:0.1;">
<div>
<audio controls>
	<source src="http://localhost/nannim/audio.mp3" type="audio/mp3">
</audio>
</div>
<?php
include 'footer.php';
?>
