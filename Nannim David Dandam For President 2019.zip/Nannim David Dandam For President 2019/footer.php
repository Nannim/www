<hr>
<table border="0" width="100%" style="position:relative;bottom:0;text-align:center;font-size:12px;">
  <th width="25%"></th><th width="25%"></th><th width="25%"></th><th width="25%"></th>
  <tr>
    <td><a href="#">Mail</a></td>
    <td><a href="#">Partners</a></td>
    <td><a href="#">Mobile</a></td>
    <td><a href="#">Extensions</a></td>
  </tr>
  <tr>
    <td><a href="#">Feedback</a></td>
    <td><a href="#">Support</a></td>
    <td><a href="#">Developer</a></td>
    <td><a href="#">Open Source</a></td>
  </tr>
  <tr>
    <td><a href="#">Connect</a></td>
    <td><a href="#">Help</a></td>
    <td><a href="#">Tools</a></td>
    <td><a href="#">EULA</a></td>
  </tr>
  <tr>
    <td>dandamnannimdavid@gmail.com</td>
    <td>Copyright &copy;</td>
    <td>Nannim David Dandam 2017.</td>
    <td>Nannim David Dandam For President 2019.</td>
  </tr>
</table>
</div>
</td>
<td></td>
</tr>
</table>
</html>
