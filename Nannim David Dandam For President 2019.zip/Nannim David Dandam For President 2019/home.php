<table border="0" width="100%">
	<tr>
	<td></td>
	<td></td>
	<td>
	<a href="Nannim David Dandam For President 2019 Poster.jpg">
		<img src="img/Nannim David Dandam For President 2019 Poster.jpg" width="100%" alt="Vote Nannim David Dandam For President 2019">
	</a>
	</td>
	<td></td>
	<td></td>
	</tr>
</table>
<tr>
<td></td>
<td>
<body>
<br>

<hr width="60%">
<br>
<h1>The National Anthem</h1>
<p>
		   Arise! O Compatriots!
	<br> Nigeria's Call Obey
	<br> To Serve Our Fatherland
	<br> With Love, Strength And Faith
	<br> The Labor Of Our Heroes Past
	<br> Shall Never Be In Vain
	<br> To Serve With Heart And Might
	<br> One Nation Bound In Freedom,
	<br> Peace And Unity.
</p>
<br>

<p>
		   Oh God Of Creation!
	<br> Direct Our Noble Cause
	<br> Guide Our Leaders Right
	<br> Our Youth The Truth To Know
	<br> In Love And Honesty To Grow
	<br> And Living Just And True
	<br> Grant Our Desires Attained
	<br> To Build A Nation Where
	<br> Peace And Justice Shall Reign.
</p>
<br>
<hr width="60%" style="opacity:0.1;">
<h1>The Pledge</h1>
<p>
			 I Pledge To Nigeria My Country
	<br> To Be Faithful Loyal And Honest
	<br> To Serve Nigeria With All My Strength,
	<br> To Defend Her Unity
	<br> To Uphold With Honour, Her Majesty
	<br> So Help Me God.
	<br> Amen.
</p>
</body>
</td>
<td></td>
</tr>
<tr>
<td></td>
<td>
