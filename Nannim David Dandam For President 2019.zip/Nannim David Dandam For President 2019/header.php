<html>
<head>
<title>NANNIM DAVID DANDAM FOR PRESIDENT 2019</title>
<link rel="shortcut icon" href="img/logo.png"/>
<link rel="stylesheet" href="css/css.css">
<table border="0" width="100%" style="text-align:center;">
<th></th>
<th></th>
<th>
  <h1 style="background:url('img/background-flag.png') no-repeat center; width:100%;position:relative;">
    <a class="absolutes">
    VOTE NANNIM DAVID DANDAM FOR PRESIDENT
    <br> 2019
    </a>
  </h1>
</th>
<th></th>
<th></th>
<tr>
<td></td>
<td></td>
<td>
<h2>
<table border="0" width="100%" style="text-align:center;">
<th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th>
<tr>
<td>
<a href="index.php"><div style="background: url('img/logo.png') center;">Home</div></a>
</td>
<td>
<a href="campaign.php"><div style="background: url('img/logo.png') center;">Campaign</div></a>
</td>
<td>
<a href="individuals.php"><div style="background: url('img/logo.png') center;">Individuals</div></a>
</td>
<td>
<a href="videos.php"><div style="background: url('img/logo.png') center;">Videos</div></a>
</td>
<td>
<a href="music.php"><div style="background: url('img/logo.png') center;">Music</div></a>
</td>
<td>
<a href="images.php"><div style="background: url('img/logo.png') center;">Images</div></a>
</td>
<td>
<a href="books.php"><div style="background: url('img/logo.png') center;">Books</div></a>
</td>
<td>
<a href="contact.php"><div style="background: url('img/logo.png') center;">Contact</div></a>
</td>
<td>
<a href="about.php"><div style="background: url('img/logo.png') center;">About</></a>
</td>
</tr>
</table>
</h2>
</td>
<td></td>
<td></td>
</tr>
</table>
</head>
