<?php
include 'header.php';
?>
<article>
<p>
  Unity, Peace and Progress!
  My Fellow Nigerians,
  To cut the very, very long story short,
  <br>
  Nigeria needs more,
  <br>
  more than we have ever had,
  <br>
  more than we think is possible to have,
  <br>
  more than we can get from oil,
  <br>
  more than we can get from one person or group of people alone,
  <br>
  more than we can ever borrow!
</p>
<p>
  Moreso, we can all agree,
  That Nigeria Deserves better,
  <br>
  better than corrupt people eating away every bit of our individual and collective efforts to be hardworking,
  <br>
  better than to be the land of frustrated and wasted youth,
  <br>
  better than to be the land of abandoned educational institutions,
  <br>
  better than to be the home of greener pasture seekers,
  <br>
  better than to be the impoverished goose that lays the golden egg,
  <br>
  better than to be the market for global waste in disguise,
  <br>
  better than to be the place for abbandoned factories,
  <br>
  better than to be the place rejected by its own people.
  <br>
  better than a place where the price of everything else depends on the price of oil
</p>
<p>
Therefore my first duty to humanity and as president would be to introduce kinetic
energy to electrical energy convertion pads manufactured in nigeria to our streets to power the dtreet lights and even our homes
generated (including the pads) by we nigerians and surplus to sell.
This innovation tackles two problems at once, rods and energy, we then employ our indigenous automobile
engineers to give us farming machinery to use and sell,
Think of Nigeria as a tourist centre,
our business is getting people to come
in and enrich us while they enjoy themselves,
our job is to take care of and enhance our business.
As a multi-national corporation with all the products/produce
we Nigeria have to offer for example our job would be to find the
best ways to sell our products/produce and make our products better while
we are at it.
<br>
Even though in reality it is almost impossible to see Nigeria through such markspersonific eyes,
due to our ethnic and political landscapes being some of the most complex in the world if not the most
complex in the world!
The Nigeria landscape still remains in need of an innovative and creative united mind
so instead of excluding the Nigerian people from sensitive matters and decisions the Nigerian
gets the head seat at the discussion table.
<br>
The Needs of the Nigerian
<br>
1. Healthcare
2. Security
3. Electricity
4. Water
5. Roads
  <h3>Major Agenda Points</h3>
<br>
1. Enhance our Agriculture so food is in good supply and exportable.
<br>
2. Enhance our Construction so Roads are pliable and houses are habitable.
<br>
3. Enhance our Healthcare.
<br>
4. Enhance/Reform our educational curriculums to enable students/pupils learn what really needs to be known, early enough.
<br>
5. Enhance our energy sector by looking to alternative sources of energy.
<br>
6. Enhance our civil service with day and night shifts where applicable, creating more jobs.
</article>

<h3>Enhancement Points</h3>
<table border="0" width="100%">
  <th>Health</th><th>Agriculture</th><th>Food</th><th>Energy</th><th>Water</th>
  <th>Transportation</th><th>Military</th><th>Commerce</th><th>Construction</th>
  <th>Education</th><th>Sports</th><th>Law Enforcement</th
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
  </tr>
</table>
<?php
include 'footer.php';
?>
