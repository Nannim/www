<?php
include 'header.php';
?>

<br>

<button style="padding:20px 20px 20px 20px; text-decoration:overline;background:url('') right top;"><img src=""></button>
<button style="padding:20px 20px 20px 20px; font-size: 100px;background:url('') right top;"><img src=""></button>
<button style="padding:20px 20px 20px 20px; text-decoration:overline;background:url('') right top;"><img src=""></button>
<button style="padding:20px 20px 20px 20px; font-size: 100px;background:url('') right top;"><img src=""></button>

<br>

<?php
include 'footer.php';
?>
